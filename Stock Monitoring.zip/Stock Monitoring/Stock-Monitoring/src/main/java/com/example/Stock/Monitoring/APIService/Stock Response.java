package com.example.Stock.Monitoring.APIService;

public class Stock Response {



import com.example.stockmonitor.dto.StockData;
import com.example.stockmonitor.dto.StockResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class StockService {
    private static final String API_KEY = "YOUR_API_KEY";
    private static final String BASE_URL = "https://www.alphavantage.co/query";

    public StockData getStockData(String symbol) {
        RestTemplate restTemplate = new RestTemplate();
        String url = String.format("%s?function=TIME_SERIES_INTRADAY&symbol=%s&interval=1min&apikey=%s", BASE_URL, symbol, API_KEY);
        ResponseEntity<StockResponse> response = restTemplate.getForEntity(url, StockResponse.class);
        return response.getBody().getTimeSeries().values().iterator().next();
    }
}
    
}
