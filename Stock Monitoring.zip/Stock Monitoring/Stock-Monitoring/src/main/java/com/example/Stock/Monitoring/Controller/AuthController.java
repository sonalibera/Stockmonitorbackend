package com.example.Stock.Monitoring.Controller;

public class AuthController {
    
}
