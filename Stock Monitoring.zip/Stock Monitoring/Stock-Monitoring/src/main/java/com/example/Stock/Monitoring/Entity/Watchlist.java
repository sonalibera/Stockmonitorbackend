package com.example.Stock.Monitoring.ElementCollectionEntity;



import lombok.Data;
import javax.persistence.*;
import java.util.List;

@Entity
@Data
public class Watchlist {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ElementCollection
    private List<String> symbols;
}