package com.example.Stock.Monitoring.Repository;

public class WatchlistRepository {


import com.example.Stock.Monitoring.Entity.Watchlist;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface WatchlistRepository extends JpaRepository<Watchlist, Long> {
    List<Watchlist> findByUserId(Long userId);
}
    
}

