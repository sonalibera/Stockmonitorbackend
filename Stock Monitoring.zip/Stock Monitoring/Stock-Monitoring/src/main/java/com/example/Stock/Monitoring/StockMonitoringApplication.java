package com.example.Stock.Monitoring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockMonitoringApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockMonitoringApplication.class, args);
	}

}
