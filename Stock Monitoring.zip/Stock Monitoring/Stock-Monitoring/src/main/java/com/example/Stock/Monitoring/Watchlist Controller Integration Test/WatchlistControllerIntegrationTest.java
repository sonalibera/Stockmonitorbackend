

// WatchlistControllerIntegrationTest.java
package com.example.Stock.Monitoring.controller;

import com.example.Stock.Monitoring.Entity.User;
import com.example.StockMonitoring.Entity.Watchlist;
import com.example.Stock.Monitoring.Repository.UserRepository;
import com.example.Stock.Monitoring.Repository.WatchlistRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@SpringBootTest
@AutoConfigureMockMvc
public class WatchlistControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private WatchlistRepository watchlistRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    private User user;

    @BeforeEach
    public void setUp() {
        userRepository.deleteAll();
        watchlistRepository.deleteAll();

        user = new User();
        user.setUsername("testuser");
        user.setPassword(passwordEncoder.encode("password"));
        user = userRepository.save(user);
    }

    @Test
    public void testCreateWatchlist() throws Exception {
        String watchlistJson = "{\"name\":\"Tech Stocks\",\"symbols\":[\"AAPL\",\"GOOGL\"],\"user\":{\"id\":" + user.getId() + "}}";

        mockMvc.perform(post("/api/watchlist")
                .contentType(MediaType.APPLICATION_JSON)
                .content(watchlistJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Tech Stocks"));
    }

    @Test
    public void testGetUserWatchlists() throws Exception {
        Watchlist watchlist = new Watchlist();
        watchlist.setName("Tech Stocks");
        watchlist.setUser(user);
        watchlist.setSymbols(Arrays.asList("AAPL", "GOOGL"));
        watchlistRepository.save(watchlist);

        mockMvc.perform(get("/api/watchlist/" + user.getId())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Tech Stocks"));
    }
}
