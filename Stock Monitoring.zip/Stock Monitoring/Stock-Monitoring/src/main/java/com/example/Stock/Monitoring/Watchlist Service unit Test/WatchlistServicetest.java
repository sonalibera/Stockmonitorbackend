
package com.example.Stock.Monitoring.Service;

import com.example.Stock.Monitoring.Entity.Watchlist;
import com.example.Stock.Monitoring.Repository.WatchlistRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class WatchlistServiceTest {

    @Mock
    private WatchlistRepository watchlistRepository;

    @InjectMocks
    private WatchlistService watchlistService;

    @Test
    public void testCreateWatchlist() {
        Watchlist watchlist = new Watchlist();
        watchlist.setName("Tech Stocks");

        when(watchlistRepository.save(any(Watchlist.class))).thenReturn(watchlist);

        Watchlist createdWatchlist = watchlistService.createWatchlist(watchlist);

        assertNotNull(createdWatchlist);
        assertEquals("Tech Stocks", createdWatchlist.getName());
        verify(watchlistRepository, times(1)).save(watchlist);
    }

    @Test
    public void testGetUserWatchlists() {
        List<Watchlist> watchlists = new ArrayList<>();
        Watchlist watchlist1 = new Watchlist();
        Watchlist watchlist2 = new Watchlist();
        watchlists.add(watchlist1);
        watchlists.add(watchlist2);

        when(watchlistRepository.findByUserId(1L)).thenReturn(watchlists);

        List<Watchlist> userWatchlists = watchlistService.getUserWatchlists(1L);

        assertNotNull(userWatchlists);
        assertEquals(2, userWatchlists.size());
        verify(watchlistRepository, times(1)).findByUserId(1L);
    }
}
