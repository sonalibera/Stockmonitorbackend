package com.example.Stock.Monitoring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockMonitoringApplicationTests {

	@Test
	void contextLoads() {
	}

}
